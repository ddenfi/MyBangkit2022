package com.ddenfi.mygithubapp2.ui

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.ddenfi.mygithubapp2.R
import com.ddenfi.mygithubapp2.adapter.ListUserAdapter
import com.ddenfi.mygithubapp2.databinding.ActivityMainBinding
import com.ddenfi.mygithubapp2.datamodel.ItemsItem
import com.ddenfi.mygithubapp2.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel
    private val adapter by lazy {
        ListUserAdapter()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.pbUser.visibility = View.GONE

        mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        mainViewModel.users.observe(this) {
            adapter.setData(it)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        setRecyclerView()
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                mainViewModel.searchUser(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }

    private fun setRecyclerView() {
        binding.rvUsers.setHasFixedSize(true)
        binding.rvUsers.layoutManager = LinearLayoutManager(this)
        val listUserAdapter = adapter
        binding.rvUsers.adapter = listUserAdapter

        listUserAdapter.setOnItemClickCallBack(object : ListUserAdapter.OnItemCLickCallBack {
            override fun onItemClicked(user: ItemsItem) {
                val toDetailActivity = Intent(this@MainActivity, DetailUserActivity::class.java)
                toDetailActivity.putExtra(DetailUserActivity.EXTRA_DATAUSER, user.login)
                startActivity(toDetailActivity)
            }
        })
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.pbUser.visibility = View.VISIBLE
        } else {
            binding.pbUser.visibility = View.GONE
        }
    }

}