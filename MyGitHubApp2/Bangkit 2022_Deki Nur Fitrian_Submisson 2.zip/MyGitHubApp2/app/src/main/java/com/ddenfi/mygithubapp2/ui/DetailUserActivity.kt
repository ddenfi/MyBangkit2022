package com.ddenfi.mygithubapp2.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.ddenfi.mygithubapp2.R
import com.ddenfi.mygithubapp2.adapter.DetailFollowAdapter
import com.ddenfi.mygithubapp2.databinding.ActivityDetailUserBinding
import com.ddenfi.mygithubapp2.datamodel.DetailUserResponse
import com.ddenfi.mygithubapp2.viewmodel.DetailViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var detailViewModel: DetailViewModel
    private var detailUser = DetailUserResponse()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.elevation = 0f

        binding.pbUser.visibility = View.GONE


        detailViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[DetailViewModel::class.java]

        val user = intent.getStringExtra(EXTRA_DATAUSER)
        detailViewModel.getDetailUser(user)


        detailViewModel.detailUsers.observe(this) {
            getDetailData(it)
        }

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        setViewPager()
    }

    private fun getDetailData(user: DetailUserResponse) {
        Glide.with(this)
            .load(user.avatarUrl)
            .circleCrop()
            .into(binding.imgDetailPhoto)
        binding.tvDetailUsername.text = "@" + user.login ?: "-"
        binding.tvDetailName.text = user.name ?: "-"
        binding.tvDetailFollowers.text = user.followers.toString()
        binding.tvDetailFollowing.text = user.following.toString()
        binding.tvDetailRepositories.text = user.publicRepos.toString()
        binding.tvDetailCompany.text = user.company ?: "-"
        binding.tvDetailLocation.text = user.location ?: "-"
    }

    private fun setViewPager() {
        val detailFollowAdapter = DetailFollowAdapter(this)
        val viewPager: ViewPager2 = binding.vpDetailFollow
        viewPager.adapter = detailFollowAdapter
        val tabs: TabLayout = binding.tabsDetailFollow

        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.pbUser.visibility = View.VISIBLE
        } else {
            binding.pbUser.visibility = View.GONE
        }
    }


    companion object {
        const val EXTRA_DATAUSER = "extra_datauser"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2

        )
    }
}