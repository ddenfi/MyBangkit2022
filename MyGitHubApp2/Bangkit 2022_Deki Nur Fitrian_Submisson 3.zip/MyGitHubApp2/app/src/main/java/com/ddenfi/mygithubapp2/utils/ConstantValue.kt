package com.ddenfi.mygithubapp2.utils

object ConstantValue {
    const val SPLASH_SCREEN_TIME = 2000L
}